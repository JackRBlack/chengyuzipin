## Scripts

这里是抓取整理数据的脚本们。


- [addAbbreviation.py](./addAbbreviation.py):  给成语添加缩写
- [clean.ipynb](./clean.ipynb): 去重重复成语
- [chengyu.py](./chengyu.py): 抓取成语
- [ci.py](./ci.py): 抓取词语
- [word.py](./word.py): 抓取汉字
- [xiehouyu.py](./xiehouyu.py): 抓取歇后语